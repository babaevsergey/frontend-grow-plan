"use client";

import type { ResourceLink } from "@/types/content";
import { useTranslation } from "@/i18n/useTranslation";

function LinkRow({ link }: { link: ResourceLink }) {
  return (
    <li>
      <a
        href={link.url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-sm text-brand-700 underline decoration-brand-200 underline-offset-2 hover:text-brand-800 hover:decoration-brand-400 dark:text-brand-400 dark:decoration-brand-500/40 dark:hover:text-brand-300"
      >
        {link.title}
      </a>
    </li>
  );
}

export function ResourcesBlock({ docs, articles }: { docs: ResourceLink[]; articles: ResourceLink[] }) {
  const { t } = useTranslation();
  if (docs.length === 0 && articles.length === 0) return null;

  return (
    <section className="rounded-lg border border-slate-200 bg-slate-50/60 p-4 dark:border-slate-700 dark:bg-slate-800/30">
      <h3 className="mb-3 text-sm font-semibold text-slate-800 dark:text-slate-200">{t.lesson.additionalResources}</h3>

      <div className="grid gap-4 sm:grid-cols-2">
        {docs.length > 0 && (
          <div>
            <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
              {t.lesson.officialDocs}
            </p>
            <ul className="flex flex-col gap-1">
              {docs.map((link) => (
                <LinkRow key={link.url} link={link} />
              ))}
            </ul>
          </div>
        )}

        {articles.length > 0 && (
          <div>
            <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
              {t.lesson.articles}
            </p>
            <ul className="flex flex-col gap-1">
              {articles.map((link) => (
                <LinkRow key={link.url} link={link} />
              ))}
            </ul>
          </div>
        )}
      </div>
    </section>
  );
}
